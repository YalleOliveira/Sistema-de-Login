import React from "react";
import { AuthProvider } from "./context/auth";
import RoutesApp from "./routes/RoutesApp";
import { GlobalStyled } from "./styles/styleGlobal";

const App = () => {
  return (
    <>
      <AuthProvider>
        <RoutesApp />
        <GlobalStyled />
      </AuthProvider>
    </>
  );
};

export default App;
